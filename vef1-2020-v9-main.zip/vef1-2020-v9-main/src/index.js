import { el, element, formatDate } from './lib/utils';
// importa öðru sem þarf...
openPopup()
document.addEventListener('DOMContentLoaded', async () => {
  // Hér er allt „vírað“ saman
});
